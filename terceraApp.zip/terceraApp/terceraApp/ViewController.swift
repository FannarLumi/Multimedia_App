//
//  ViewController.swift
//  terceraApp
//
//  Created by Alumno on 19/10/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func buttonImagen(_ sender: Any) {
        guard let vc = storyboard?.instantiateViewController(withIdentifier: "image_vc") as? ImageViewController else {
            return
        }
        present(vc, animated: true)
    }
}

