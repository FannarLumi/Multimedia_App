//
//  ImageViewController.swift
//  terceraApp
//
//  Created by Alumno on 19/10/22.
//

import UIKit
import AVKit

class ImageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func regresarMenu(_ sender: Any) {
        self.dismiss(animated:true)
    }
    @IBAction func mostrarVideo(_ sender: Any) {
            let ruta = Bundle.main.path(forResource: "amarillo", ofType: "mp4")
            let player = AVPlayerViewController()
            let videoUrl = URL(filePath: ruta!)
            let video = AVPlayer(url: videoUrl)
            player.player = video
            present(player, animated: true, completion: {
                video.play()
            })
    }
    

}
