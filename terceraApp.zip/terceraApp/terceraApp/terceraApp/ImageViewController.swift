//
//  ImageViewController.swift
//  terceraApp
//
//  Created by Alumno on 19/10/22.
//

import UIKit

class ImageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonVideo(_ sender: Any) {
        guard let vc = storyboard?.instantiateViewController(withIdentifier: "video_vc") as? VideoViewController else {
            return
        }
        present(vc, animated: true)
    }
    


}
